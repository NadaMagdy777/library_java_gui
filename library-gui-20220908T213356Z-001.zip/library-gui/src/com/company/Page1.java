package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.beans.PropertyChangeListener;

public class Page1 {
    public static void Page1(){
        JFrame page1=new JFrame(Library.name);
        page1.setSize(500,400);
        page1.setVisible(true);
        page1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        page1.setResizable(false);
        page1.setLayout(null);
        Font f1=new Font("Arial",Font.BOLD,15);
        JButton b1=new JButton(" librarian ");
        page1.add(b1);
        b1.setBounds(50,50,250,30);
        b1.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                page2.librarian();
                page1.setVisible(false);

            }
        });
        b1.setFont(f1);
        JButton b2=new JButton(" Student ");
        b2.setBounds(50,100,250,30);
        page1.add(b2);
        b2.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                StudentGui.Student();
                page1.setVisible(false);
            }
        });
        b2.setFont(f1);
        JButton b3=new JButton("payment System");
        b3.setBounds(50,150,250,30);
        page1.add(b3);
        b3.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                PaymentGui.PaymentSystem();
                page1.setVisible(false);
            }
        });
        b3.setFont(f1);
    }

}
