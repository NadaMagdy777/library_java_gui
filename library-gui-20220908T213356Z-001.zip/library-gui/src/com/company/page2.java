package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class page2 {
    public static void librarian() {
        JFrame page1 = new JFrame(Library.name);
        page1.setSize(500, 400);
        page1.setVisible(true);
        page1.setLayout(null);
        page1.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        page1.setResizable(false);
        JLabel j = new JLabel("PLease enter password", JLabel.LEFT);
        j.setBounds(50, 50, 250, 30);
        page1.add(j);
        JTextField F1 = new JPasswordField();
        F1.setBounds(200, 50, 250, 30);
        page1.add(F1);
        JButton b1 = new JButton("ok");
        b1.setBounds(100, 100, 250, 30);
        page1.add(b1);
        b1.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (F1.getText().equals(Librarian.getPassward())) {
                    librarianOperation();
                    page1.setVisible(false);

                } else {
                    JLabel b = new JLabel("password is not true ");
                    b.setBounds(100, 150, 250, 30);
                    page1.add(b);
                    Font f1 = new Font("Arial", Font.BOLD, 15);
                    b.setForeground(Color.red);
                    b.setFont(f1);
                }
            }
        });
        JButton b3 = new JButton(" Cancel ");
        b3.setBounds(100, 200, 250, 30);
        page1.add(b3);
        b3.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                page1.setVisible(false);
               Page1.Page1();
            }
        });


    }

    public static void librarianOperation() {
        JFrame page1 = new JFrame(Library.name);
        page1.setSize(500, 400);
        page1.setVisible(true);
        page1.setLayout(null);
        page1.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        page1.setResizable(false);
        JButton b1 = new JButton(" Display books ");
        page1.add(b1);
        b1.setBounds(50, 50, 300, 30);
        b1.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                BookOperation.DisplayAll();
            }
        });
        JButton b2 = new JButton(" Add book ");
        page1.add(b2);
        b2.setBounds(50, 100, 300, 30);
        b2.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame f2 = new JFrame();
                f2.setSize(500, 400);
                f2.setVisible(true);
                f2.setLayout(null);
                page1.setVisible(false);
                f2.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
                f2.setResizable(false);
                JButton b = new JButton(" Add booklet ");
                b.setBounds(100, 100, 300, 30);
                f2.add(b);
                b.addActionListener(new AbstractAction() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        addBooklet();
                        f2.setVisible(false);
                        page1.setVisible(false);
                    }
                });
                JButton b1 = new JButton("  Add  Magazine  ");
                b1.setBounds(100, 150, 300, 30);
                f2.add(b1);
                b1.addActionListener(new AbstractAction() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        addMagazine();
                        f2.setVisible(false);
                        page1.setVisible(false);

                    }
                });
                JButton b3 = new JButton(" Cancel ");
                b3.setBounds(100, 200, 300, 30);
                f2.add(b3);
                b3.addActionListener(new AbstractAction() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        f2.setVisible(false);
                        page1.setVisible(true);
                    }
                });

            }
        });
        JButton b3 = new JButton(" Search book ");
        b3.setBounds(50, 150, 300, 30);
        page1.add(b3);
        b3.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Search();
            }
        });
        JButton b4 = new JButton(" modify book ");
        b4.setBounds(50, 200, 300, 30);
        page1.add(b4);
        b4.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                modify();
                page1.setVisible(false);
            }
        });
        JButton b5 = new JButton("delete book");
        b5.setBounds(50, 250, 300, 30);
        page1.add(b5);
        b5.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                delete();
                page1.setVisible(false);
            }
        });
        JButton b6 = new JButton("EXIT");
        b6.setBounds(50, 300, 300, 30);
        page1.add(b6);
        b6.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                page1.setVisible(false);
                Page1.Page1();
            }
        });
    }
    public static void addBooklet() {
        JFrame f2 = new JFrame();
        f2.setSize(500, 400);
        f2.setVisible(true);
        f2.setLayout(null);
        f2.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        f2.setResizable(false);
        JLabel l1 = new JLabel("enter  the name of booklet");
        l1.setBounds(50, 50, 200, 30);
        JTextField f = new JTextField();
        f.setBounds(250, 50, 200, 30);
        f2.add(l1);
        f2.add(f);
        JLabel l2 = new JLabel("enter  the price of booklet");
        l2.setBounds(50, 100, 200, 30);
        JTextField f3 = new JTextField();
        f3.setBounds(250, 100, 200, 30);
        f2.add(l2);
        f2.add(f3);
        JLabel l3 = new JLabel("enter  the noc of booklet");
        l3.setBounds(50, 150, 200, 30);
        JTextField f4 = new JTextField();
        f4.setBounds(250, 150, 200, 30);
        f2.add(l3);
        f2.add(f4);
        JLabel b = new JLabel();
        b.setBounds(200, 250, 100, 30);
        f2.add(b);
        JButton b1 = new JButton("Add booklet");
        b1.setBounds(200, 200, 150, 30);
        f2.add(b1);
        b1.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    long i = Long.parseLong(f3.getText());
                    long j = Long.parseLong(f4.getText());
                    if(!f.getText().equals("")) {
                        Booklet m = new Booklet(f.getText().toLowerCase(), i, j);
                        BookOperation.addBook(m);
                        f2.setVisible(false);
                        librarianOperation();
                    }
                    else{
                        Exception x=new Exception();
                        throw x;
                    }
                } catch (Exception ex) {
                    Font f1 = new Font("Arial", Font.BOLD, 15);
                    b.setForeground(Color.red);
                    b.setFont(f1);
                    b.setText("error in input");
                }

            }
        });
    }

    public static void addMagazine() {
        JFrame f2 = new JFrame();
        f2.setSize(500, 400);
        f2.setVisible(true);
        f2.setLayout(null);
        f2.setResizable(false);
        f2.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        JLabel l1 = new JLabel("enter  the name of Magazine");
        l1.setBounds(50, 50, 200, 30);
        JTextField f = new JTextField();
        f.setBounds(250, 50, 200, 30);
        f2.add(l1);
        f2.add(f);
        JLabel l2 = new JLabel("enter  the price of Magazine");
        l2.setBounds(50, 100, 200, 30);
        JTextField f3 = new JTextField();
        f3.setBounds(250, 100, 200, 30);
        f2.add(l2);
        f2.add(f3);
        JLabel l3 = new JLabel("enter  the noc of Magazine");
        l3.setBounds(50, 150, 200, 30);
        JTextField f4 = new JTextField();
        f4.setBounds(250, 150, 200, 30);
        f2.add(l3);
        f2.add(f4);
        JLabel b = new JLabel();
        b.setBounds(200, 250, 100, 30);
        f2.add(b);
        JButton b1 = new JButton("Add Magazine");
        b1.setBounds(200, 200, 150, 30);
        f2.add(b1);
        b1.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    long i = Long.parseLong(f3.getText());
                    long j = Long.parseLong(f4.getText());
                    if(!f.getText().equals("")) {
                        Magazine m = new Magazine(f.getText().toLowerCase(), i, j);
                        BookOperation.addBook(m);
                        f2.setVisible(false);
                        librarianOperation();
                    }
                    else{
                        Exception x=new Exception();
                        throw x;
                    }
                } catch (Exception ex) {
                    Font f1 = new Font("Arial", Font.BOLD, 15);
                    b.setForeground(Color.red);
                    b.setFont(f1);
                    b.setText("error in input");
                }

            }
        });

    }

    public static void Search() {
        JFrame f2 = new JFrame();
        f2.setSize(500, 400);
        f2.setVisible(true);
        f2.setLayout(null);
        JLabel l1 = new JLabel("enter the name of book");
        l1.setBounds(100, 100, 250, 30);
        f2.add(l1);
        JTextField t = new JTextField();
        t.setBounds(260, 100, 250, 30);
        f2.add(t);
        JButton b = new JButton("Search");
        b.setBounds(190, 150, 100, 30);
        f2.add(b);
        b.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                BookOperation.searchBook(t.getText().toLowerCase());
                f2.setVisible(false);
            }
        });
    }

    public static void modify() {
        JFrame f2 = new JFrame();
        f2.setSize(500, 400);
        f2.setVisible(true);
        f2.setLayout(null);
        f2.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        f2.setResizable(false);
        JLabel l1 = new JLabel("enter the name of book");
        l1.setBounds(50, 50, 250, 30);
        f2.add(l1);
        JTextField t = new JTextField();
        t.setBounds(260, 50, 200, 30);
        f2.add(t);
        JLabel l2 = new JLabel("Book Type");
        l2.setBounds(50, 100, 250, 30);
        f2.add(l2);
        JComboBox c = new JComboBox(new String[]{"booklet", "Magazine"});
        c.setBounds(260, 100, 200, 30);
        f2.add(c);
        JLabel l3 = new JLabel("0 for modify price");
        l3.setBounds(50, 150, 250, 45);
        f2.add(l3);
        JLabel l4 = new JLabel("1 for modify name ");
        l4.setBounds(50, 165, 250, 45);
        f2.add(l4);
        JLabel l5 = new JLabel("2 for modify noc");
        l5.setBounds(50, 180, 250, 45);
        f2.add(l5);
        JComboBox c2 = new JComboBox(new String[]{"0", "1", "2"});
        c2.setBounds(260, 160, 200, 40);
        f2.add(c2);
        JButton b = new JButton("modify");
        b.setBounds(180, 250, 150, 30);
        f2.add(b);
        b.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    BookOperation.modify(t.getText().toLowerCase(), c2.getSelectedIndex(), c.getSelectedItem() + "");
                    f2.setVisible(false);
                } catch (Exception ex) {
                    JLabel l2 = new JLabel("error in input");
                    l2.setBounds(190, 250, 250, 30);
                    f2.add(l2);
                }


            }
        });
    }

    public static void delete() {
        JFrame f2 = new JFrame();
        f2.setSize(500, 400);
        f2.setVisible(true);
        f2.setLayout(null);
        f2.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        f2.setResizable(false);
        JLabel l1 = new JLabel("enter the name of book");
        l1.setBounds(50, 50, 250, 30);
        f2.add(l1);
        JTextField t = new JTextField();
        t.setBounds(260, 50, 200, 30);
        f2.add(t);
        JLabel l2 = new JLabel("Book Type");
        l2.setBounds(50, 100, 250, 30);
        f2.add(l2);
        JComboBox c = new JComboBox(new String[]{"booklet", "Magazine"});
        c.setBounds(260, 100, 200, 30);
        f2.add(c);
        JButton b = new JButton("Delete");
        b.setBounds(190, 200, 150, 30);
        f2.add(b);
        b.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    BookOperation.deleteBook(t.getText().toLowerCase(), c.getSelectedItem() + "");
                    f2.setVisible(false);
                } catch (Exception ex) {
                    JLabel l2 = new JLabel("error in input");
                    l2.setBounds(190, 250, 250, 30);
                    f2.add(l2);
                }


            }
        });
    }


}

