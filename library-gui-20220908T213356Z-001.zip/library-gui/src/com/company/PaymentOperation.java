package com.company;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.Collections;
public class PaymentOperation {
    public static final String pass = "123";
    static ArrayList<Borrow> borrow = new ArrayList<>();
    static ArrayList<Borrow> OverPeriodBorrow = new ArrayList<>();
    static ArrayList<Borrow> allProfits = new ArrayList<>();
static long allprofit;
    public static long ProfitBorrow() {
        long profits = 0;
        for (Borrow b : borrow) {
            b.setStatus("without fine");
            profits += b.getPrice();
            allprofit+=b.getPrice();
        }
        return profits;
    }

    public static long ProfitOverPeriodBorrow() {
        long profits = 0;
        for (Borrow b : OverPeriodBorrow) {
            b.setStatus("with fine");
            profits += b.getPrice() + 15;
            allprofit+=b.getPrice()+15;
        }
        return profits;
    }

    public static void ShowProfitBorrow() {
        System.out.println(ProfitBorrow());
    }

    public static void ShowOverPeriodBorrow() {
        System.out.println(ProfitOverPeriodBorrow());
    }

    public static void allProfits() {
        ProfitOverPeriodBorrow();
        ProfitBorrow();
        JFrame f2 = new JFrame();
        f2.setSize(500, 400);
        f2.setVisible(true);
        f2.setLayout(null);
        JLabel l1 = new JLabel(allprofit+"");
        l1.setBounds(50, 50, 200, 30);
        f2.add(l1);
        JButton b3 = new JButton(" Cancel ");
        b3.setBounds(100, 100, 300, 30);
        f2.add(b3);
        b3.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                f2.setVisible(false);
                PaymentGui.PaymentOperation();
            }
        });
    }

    public static void DisplayBorrowList() {
        ProfitBorrow();
        ProfitOverPeriodBorrow();
        JFrame f2 = new JFrame();
        f2.setSize(500, 400);
        f2.setVisible(true);
        f2.setLayout(null);
        int j = 0;
        if (borrow.isEmpty()) {
            JLabel l1 = new JLabel("not found borrow books to show it");
            l1.setBounds(50, 50, 200, 30);
            f2.add(l1);
        } else {
            Collections.sort(borrow);
            for (int i = 0; i < borrow.size(); i++) {
                JLabel l1 = new JLabel(borrow.get(i).toString());
                l1.setBounds(50, 50 + j, 200, 30);
                f2.add(l1);
                j = j + 50;

            }
        }
        JButton b3 = new JButton(" Cancel ");
        b3.setBounds(100, 100 + j, 300, 30);
        f2.add(b3);
        b3.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                f2.setVisible(false);
                PaymentGui.PaymentOperation();
            }
        });
    }

    public static void DisplayOverPeriodBorrowList() {
        ProfitBorrow();
        ProfitOverPeriodBorrow();
        JFrame f2 = new JFrame();
        f2.setSize(500, 400);
        f2.setVisible(true);
        f2.setLayout(null);
        int j = 0;
        if (OverPeriodBorrow.isEmpty()) {
            JLabel l1 = new JLabel("not found borrow books to show it");
            l1.setBounds(50, 50, 200, 30);
            f2.add(l1);
        } else {
            Collections.sort(OverPeriodBorrow);
            for (int i = 0; i < OverPeriodBorrow.size(); i++) {
                JLabel l1 = new JLabel(OverPeriodBorrow.get(i).toString());
                l1.setBounds(50, 50 + j, 200, 30);
                f2.add(l1);
                j = j + 50;

            }

        }
        JButton b3 = new JButton(" Cancel ");
        b3.setBounds(100, 100 + j, 300, 30);
        f2.add(b3);
        b3.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                f2.setVisible(false);
                PaymentGui.PaymentOperation();
            }
        });
    }

    public static void DisplayAllProfitsList() {
        ProfitBorrow();
        ProfitOverPeriodBorrow();
        JFrame f2 = new JFrame();
        f2.setSize(500, 400);
        f2.setVisible(true);
        f2.setLayout(null);
        int j = 0;
        if (allProfits.isEmpty()) {
            JLabel l1 = new JLabel("not found borrow books to show it");
            l1.setBounds(50, 50, 200, 30);
            f2.add(l1);
        } else {
            Collections.sort(allProfits);
            for (int i = 0; i < allProfits.size(); i++) {
                JLabel l1 = new JLabel(allProfits.get(i).toString());
                l1.setBounds(50, 50 + j, 200, 30);
                f2.add(l1);
                j = j + 50;

            }
        }
        JButton b3 = new JButton(" Cancel ");
        b3.setBounds(100, 100 + j, 300, 30);
        f2.add(b3);
        b3.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                f2.setVisible(false);
                PaymentGui.PaymentOperation();
            }
        });

    }
}
