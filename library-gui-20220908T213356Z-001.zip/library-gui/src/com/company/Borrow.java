package com.company;

import java.util.Date;

public class Borrow implements Comparable<Borrow> {
    private double price;
    private String BookBorrowName;
    private Date borrowDate = new Date();
    private String SName;
    private String status = "";

    Borrow(String name, Date borrowDate, String SName, double price) {
        this.BookBorrowName = name;
        this.borrowDate = borrowDate;
        this.SName = SName;
        this.price = price;
    }

    public String getBookBorrowName() {
        return BookBorrowName;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public Date getBorrowDate() {
        return borrowDate;
    }

    @Override
    public String toString() {
        return BookBorrowName + "  " + price + "   " + SName + "   " + status;
    }

    public String getSName() {
        return SName;
    }

    public void setSName(String SName) {
        if (!SName.equals(null))
            this.SName = SName.toLowerCase();

    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public int compareTo(Borrow o) {
        int c = BookBorrowName.compareTo(o.BookBorrowName);
        if (c > 0) {
            return 1;
        } else if (c < 0) {
            return -1;
        } else {
            return 0;
        }


    }

}

