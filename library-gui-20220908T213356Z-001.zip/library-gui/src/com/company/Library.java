package com.company;

public interface Library {
    String name = "lap library ";
    int  id=100;
}
