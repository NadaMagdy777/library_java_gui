package com.company;

import java.util.Scanner;

public class Librarian {

    static Scanner sc=new Scanner(System.in);
    String name;
    static final private String Passward="123456";
    public static String getPassward() {
        return Passward;
    }
}
