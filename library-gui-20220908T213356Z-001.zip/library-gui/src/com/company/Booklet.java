package com.company;

public class Booklet extends Book {
    String author;
     private long bid;
    static BookOperation StudyBook;
    Booklet(String name, double price, long noc) {
        setName(name);
        setPrice(price);
        setNoc(noc);
        bid=id;
        id++;
    }
    @Override
    public String toString() {
        return ( bid+ "    "+getName()+ "     "  +getPrice()+"     " +getNoc()+"    "+"booklet"+"\r\n");
    }
}
