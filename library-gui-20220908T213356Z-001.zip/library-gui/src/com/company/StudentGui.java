package com.company;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.util.Date;

public class StudentGui {
    public static void Student() {
        JFrame page1 = new JFrame(Library.name);
        page1.setSize(500, 400);
        page1.setVisible(true);
        page1.setLayout(null);
        page1.setLayout(null);
        page1.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        JLabel j = new JLabel("enter your name please ", JLabel.LEFT);
        j.setBounds(50, 50, 250, 30);
        page1.add(j);
        JTextField F1 = new JTextField();
        F1.setBounds(200, 50, 250, 30);
        page1.add(F1);
        JButton b1 = new JButton("ok");
        b1.setBounds(100, 100, 250, 30);
        page1.add(b1);
        b1.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(!F1.getText().equals("")) {
                    Student s = new Student(F1.getText().toLowerCase());
                    Student.addStudent(s);
                    StudentOperation();
                    page1.setVisible(false);
                }

            }
        });
        JButton b3 = new JButton(" Cancel ");
        b3.setBounds(100, 200, 250, 30);
        page1.add(b3);
        b3.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                page1.setVisible(false);
                Page1.Page1();
            }
        });



    }
    public static void StudentOperation() {
        JFrame page1 = new JFrame(Library.name);
        page1.setSize(500, 400);
        page1.setVisible(true);
        page1.setLayout(null);
        page1.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        page1.setResizable(false);
        JButton b1 = new JButton("  Display books ");
        page1.add(b1);
        b1.setBounds(50, 50, 300, 30);
        b1.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                BookOperation.DisplayAll();
            }
        });
        JButton b2 = new JButton(" Borrow Book ");
        page1.add(b2);
        b2.setBounds(50, 100, 300, 30);
        b2.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                  borrow();
                page1.setVisible(false);
            }
        });
        JButton b3 = new JButton(" Search book ");
        b3.setBounds(50, 150, 300, 30);
        page1.add(b3);
        b3.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Search();
            }
        });
        JButton b4 = new JButton(" Receive book ");
        b4.setBounds(50, 200, 300, 30);
        page1.add(b4);
        b4.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                     receive();
                page1.setVisible(false);
            }
        });
        JButton b6 = new JButton("EXIT");
        b6.setBounds(50, 250, 300, 30);
        page1.add(b6);
        b6.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                page1.setVisible(false);
                Page1.Page1();
            }
        });
    }
    public static void  Search(){
        JFrame f2 = new JFrame();
        f2.setSize(500, 400);
        f2.setVisible(true);
        f2.setLayout(null);
        f2.setLayout(null);
        f2.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        JLabel l1=new JLabel("enter the name of book");
        l1.setBounds(100,100,250,30);
        f2.add(l1);
        JTextField t=new JTextField();
        t.setBounds(260,100,250,30);
        f2.add(t);
        JButton b=new JButton("Search");
        b.setBounds(190,150,100,30);
        f2.add(b);
        b.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                BookOperation.searchBook(t.getText().toLowerCase());
                f2.setVisible(false);
            }
        });
    }
    public static void borrow(){
        JFrame f2 = new JFrame();
        f2.setSize(500, 400);
        f2.setVisible(true);
        f2.setLayout(null);
        f2.setLayout(null);
        f2.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        JLabel l1=new JLabel("enter the name of book");
        l1.setBounds(50,50,250,30);
        f2.add(l1);
        JTextField t=new JTextField();
        t.setBounds(260,50,200,30);
        f2.add(t);
        JLabel l2=new JLabel(" please enter your name ");
        l2.setBounds(50,100,250,30);
        f2.add(l2);
        JTextField t1=new JTextField();
        t1.setBounds(260,100,200,30);
        f2.add(t1);
        JLabel l3=new JLabel("Book Type");
        l3.setBounds(50,150,250,30);
        f2.add(l3);
        JComboBox c=new JComboBox(new String[]{"booklet","Magazine"});
        c.setBounds(260,150,200,30);
        f2.add(c);
        JButton b=new JButton("Borrow");
        b.setBounds(180,200,150,30);
        f2.add(b);
        b.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    BookOperation.borrow(t.getText(),new Date(),t1.getText(),c.getSelectedItem()+"");
                    f2.setVisible(false);
                }catch (Exception ex){
                    JLabel l2=new JLabel("error in input");
                    l2.setBounds(190,250,250,30);
                    f2.add(l2);
                }
            }
        });
    }
    public static void receive(){
        JFrame f2 = new JFrame();
        f2.setSize(500, 400);
        f2.setVisible(true);
        f2.setLayout(null);
        JLabel l1=new JLabel("enter the name of book");
        l1.setBounds(50,50,250,30);
        f2.add(l1);
        JTextField t=new JTextField();
        t.setBounds(260,50,200,30);
        f2.add(t);
        JLabel l2=new JLabel(" please enter your name ");
        l2.setBounds(50,100,250,30);
        f2.add(l2);
        JTextField t1=new JTextField();
        t1.setBounds(260,100,200,30);
        f2.add(t1);
        JButton b=new JButton("Receive");
        b.setBounds(180,150,150,30);
        f2.add(b);
        b.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    BookOperation.ReceiveBook(t.getText(),new Date(),t1.getText());
                    f2.setVisible(false);
                    StudentGui.StudentOperation();
                }catch (Exception ex){
                    JLabel l2=new JLabel("error in input");
                    l2.setBounds(190,250,250,30);
                    f2.add(l2);
                }
            }
        });
    }


}
