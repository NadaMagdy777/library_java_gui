package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.geom.Arc2D;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

public class BookOperation {
    static Scanner sc = new Scanner(System.in);
    static ArrayList<Book> books = new ArrayList<>();
    static ArrayList<com.company.Magazine> Magazine = new ArrayList<>();
    static ArrayList<Booklet> booklet = new ArrayList<>();
    static PaymentOperation Payment;

    public static void searchBook(String name) {
        int j = 0;
        JFrame f2 = new JFrame();
        f2.setSize(500, 400);
        f2.setVisible(true);
        f2.setLayout(null);
        f2.setResizable(false);
        f2.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        String Name = name.toLowerCase();
        int i = searchBookBorrow(Name, "books");
        if (books.isEmpty()) {
            JLabel l1 = new JLabel("no books in library");
            l1.setBounds(50, 50, 200, 30);
            f2.add(l1);
            JButton b1 = new JButton("Cancel");
            b1.setBounds(190, 100, 150, 30);
            f2.add(b1);
            b1.addActionListener(new AbstractAction() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    f2.setVisible(false);

                }
            });
        } else if (i != -1) {
            JLabel l1 = new JLabel(Name);
            l1.setBounds(50, 50, 200, 30);
            f2.add(l1);
            JButton b1 = new JButton("Cancel");
            b1.setBounds(190, 50 + j, 150, 30);
            f2.add(b1);
            b1.addActionListener(new AbstractAction() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    f2.setVisible(false);
                }
            });
        } else {
            for (Book B : books) {
                if (B.getName().contains(Name)) {
                    JLabel l1 = new JLabel(B.getName());
                    l1.setBounds(50, 50 + j, 200, 30);
                    f2.add(l1);
                    j = j + 50;
                    continue;
                } else if (B.equals(books.get(books.size() - 1))) {
                    JLabel l1 = new JLabel("the book is not found in library");
                    l1.setBounds(50, 50 + j, 200, 30);
                    f2.add(l1);
                    j = j + 50;

                }
            }
            JButton b1 = new JButton("Cancel");
            b1.setBounds(190, 50 + j, 150, 30);
            f2.add(b1);
            b1.addActionListener(new AbstractAction() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    f2.setVisible(false);
                }
            });

        }
    }

    public static int searchBookBorrow(String name, String type) {
        if (type.equals("booklet")) {
            for (Booklet b : booklet) {
                if (b.getName().equals(name.toLowerCase())) {
                    return books.indexOf(b);
                }
            }

        } else if (type.equals("Magazine")) {
            for (Magazine b : Magazine) {
                if (b.getName().equals(name.toLowerCase())) {
                    return books.indexOf(b);
                }
            }
        } else if (type.equals("books")) {
            for (Book b : books) {
                if (b.getName().equals(name.toLowerCase())) {
                    return books.indexOf(b);
                }
            }
        }
        return -1;
    }

    public static void deleteBook(String name, String type) {
        JFrame f2 = new JFrame();
        f2.setSize(500, 400);
        f2.setVisible(true);
        f2.setLayout(null);
        f2.setResizable(false);
        f2.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        int i = searchBookBorrow(name.toLowerCase(), type);
        if (i != -1) {
            books.remove(i);
            JLabel l1 = new JLabel("This book is  deleted");
            l1.setBounds(50, 50, 200, 30);
            f2.add(l1);
            JButton b1 = new JButton("Cancel");
            b1.setBounds(190, 100, 150, 30);
            f2.add(b1);
            b1.addActionListener(new AbstractAction() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    f2.setVisible(false);
                    page2.librarianOperation();
                }
            });
        } else {
            JLabel l1 = new JLabel("This book is not found to delete");
            l1.setBounds(50, 50, 200, 30);
            f2.add(l1);
            JButton b1 = new JButton("Cancel");
            b1.setBounds(190, 100, 150, 30);
            f2.add(b1);
            b1.addActionListener(new AbstractAction() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    f2.setVisible(false);
                    page2.librarianOperation();
                }
            });

        }
    }

    public static void borrow(String name, Date borrowDate, String sname, String type) {
        JFrame f2 = new JFrame();
        f2.setSize(500, 400);
        f2.setVisible(true);
        f2.setLayout(null);
        f2.setResizable(false);
        f2.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        int i = searchBookBorrow(name.toLowerCase(), type);
        if (i != -1) {
            if (books.get(i).getNoc() >= 1) {
                books.get(i).setNoc(books.get(i).getNoc() - 1);
                Borrow s = new Borrow(name, borrowDate, sname, books.get(i).getPrice() + 20);
                PaymentOperation.borrow.add(s);
                Payment.allProfits.add(s);
                JLabel l1 = new JLabel("you borrowed book");
                l1.setBounds(50, 50, 200, 30);
                f2.add(l1);
                JButton b1 = new JButton("Cancel");
                b1.setBounds(190, 100, 150, 30);
                f2.add(b1);
                b1.addActionListener(new AbstractAction() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        f2.setVisible(false);
                        StudentGui.StudentOperation();
                    }
                });

            } else {
                JLabel l1 = new JLabel("THIS book has no copies now");
                l1.setBounds(50, 50, 200, 30);
                f2.add(l1);
                JButton b1 = new JButton("Cancel");
                b1.setBounds(190, 100, 150, 30);
                f2.add(b1);
                b1.addActionListener(new AbstractAction() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        f2.setVisible(false);
                        StudentGui.StudentOperation();
                    }
                });

            }
        } else {
            JLabel l1 = new JLabel("THIS book is not found to borrow it");
            l1.setBounds(50, 50, 200, 30);
            f2.add(l1);
            JButton b1 = new JButton("Cancel");
            b1.setBounds(190, 100, 150, 30);
            f2.add(b1);
            b1.addActionListener(new AbstractAction() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    f2.setVisible(false);
                    StudentGui.StudentOperation();
                }
            });

        }
    }

    public static void addBook(Book B) {
        if (B instanceof Booklet) {
            int i = searchBookBorrow(B.getName(), "booklet");
            if (i != -1) {
                books.get(i).setNoc(books.get(i).getNoc() + 1);
            } else {
                books.add(B);
                booklet.add((Booklet) B);

            }
        } else if (B instanceof Magazine) {
            int i = searchBookBorrow(B.getName(), "magazine");
            if (i != -1) {
                books.get(i).setNoc(books.get(i).getNoc() + 1);
            } else {
                books.add(B);
                Magazine.add((Magazine) B);

            }
        }
    }

    public static void modify(String name, long num, String type) {
        JFrame f2 = new JFrame();
        f2.setSize(500, 400);
        f2.setVisible(true);
        f2.setLayout(null);
        f2.setResizable(false);
        f2.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        String Name = name.toLowerCase();
        int i = searchBookBorrow(Name, type);
        if (i != -1) {
            if (books.get(i) instanceof Booklet) {
                if (num == 0) {
                    JLabel l1 = new JLabel("Enter the edit of booklet price ");
                    l1.setBounds(50, 50, 250, 30);
                    f2.add(l1);
                    JTextField T1 = new JTextField();
                    T1.setBounds(260, 50, 200, 30);
                    f2.add(T1);
                    JButton b1 = new JButton("Modify");
                    b1.setBounds(190, 100, 150, 30);
                    f2.add(b1);
                    b1.addActionListener(new AbstractAction() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            try {
                                books.get(i).setPrice(Double.parseDouble(T1.getText()));
                                f2.setVisible(false);
                                page2.librarianOperation();
                            } catch (Exception ex) {
                                JLabel b = new JLabel("input is error ");
                                b.setBounds(100, 150, 250, 30);
                                Font f1 = new Font("Arial", Font.BOLD, 15);
                                b.setForeground(Color.red);
                                b.setFont(f1);
                                f2.add(b);
                            }
                        }
                    });
                } else if (num == 1) {
                    JLabel l1 = new JLabel("Enter the edit of booklet name ");
                    l1.setBounds(50, 50, 250, 30);
                    f2.add(l1);
                    JTextField T1 = new JTextField();
                    T1.setBounds(260, 50, 200, 30);
                    f2.add(T1);
                    JButton b1 = new JButton("Modify");
                    b1.setBounds(190, 100, 150, 30);
                    f2.add(b1);
                    b1.addActionListener(new AbstractAction() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            try {
                                if (!T1.getText().equals("")) {
                                    books.get(i).setName(T1.getText());
                                    f2.setVisible(false);
                                    page2.librarianOperation();
                                } else {
                                    Exception o = new Exception();
                                    throw o;
                                }
                            } catch (Exception ex) {
                                JLabel b = new JLabel("input is error ");
                                b.setBounds(100, 150, 250, 30);
                                Font f1 = new Font("Arial", Font.BOLD, 15);
                                b.setForeground(Color.red);
                                b.setFont(f1);
                                f2.add(b);
                            }
                        }
                    });
                } else if (num == 2) {
                    JLabel l1 = new JLabel("Enter the edit of booklet copies ");
                    l1.setBounds(50, 50, 250, 30);
                    f2.add(l1);
                    JTextField T1 = new JTextField();
                    T1.setBounds(260, 50, 200, 30);
                    f2.add(T1);
                    JButton b1 = new JButton("Modify");
                    b1.setBounds(190, 100, 150, 30);
                    f2.add(b1);
                    b1.addActionListener(new AbstractAction() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            try {
                                books.get(i).setNoc(Long.parseLong(T1.getText()));
                                f2.setVisible(false);
                                page2.librarianOperation();
                            } catch (Exception ex) {
                                JLabel b = new JLabel("input is error ");
                                b.setBounds(100, 150, 250, 30);
                                Font f1 = new Font("Arial", Font.BOLD, 15);
                                b.setForeground(Color.red);
                                b.setFont(f1);
                                f2.add(b);
                            }
                        }
                    });
                }
            } else if (books.get(i) instanceof Magazine) {
                if (num == 0) {
                    JLabel l1 = new JLabel("Enter the edit of magazine price ");
                    l1.setBounds(50, 50, 250, 30);
                    f2.add(l1);
                    JTextField T1 = new JTextField();
                    T1.setBounds(260, 50, 200, 30);
                    f2.add(T1);
                    JButton b1 = new JButton("Modify");
                    b1.setBounds(190, 100, 150, 30);
                    f2.add(b1);
                    b1.addActionListener(new AbstractAction() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            try {
                                books.get(i).setPrice(Double.parseDouble(T1.getText()));
                                f2.setVisible(false);
                                page2.librarianOperation();
                            } catch (Exception ex) {
                                JLabel b = new JLabel("input is error ");
                                b.setBounds(100, 150, 250, 30);
                                Font f1 = new Font("Arial", Font.BOLD, 15);
                                b.setForeground(Color.red);
                                b.setFont(f1);
                                f2.add(b);
                            }

                        }
                    });

                }
            } else if (num == 1) {
                JLabel l1 = new JLabel("Enter the edit of magazine name ");
                l1.setBounds(50, 50, 250, 30);
                f2.add(l1);
                JTextField T1 = new JTextField();
                T1.setBounds(260, 50, 200, 30);
                f2.add(T1);
                JButton b1 = new JButton("Modify");
                b1.setBounds(190, 100, 150, 30);
                f2.add(b1);
                b1.addActionListener(new AbstractAction() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            if (!T1.getText().equals("")) {
                                books.get(i).setName(T1.getText());
                                f2.setVisible(false);
                                page2.librarianOperation();
                            } else {
                                Exception o = new Exception();
                                throw o;
                            }
                        } catch (Exception ex) {
                            JLabel b = new JLabel("input is error ");
                            b.setBounds(100, 150, 250, 30);
                            Font f1 = new Font("Arial", Font.BOLD, 15);
                            b.setForeground(Color.red);
                            b.setFont(f1);
                            f2.add(b);
                        }

                    }
                });
            } else if (num == 2) {
                JLabel l1 = new JLabel("Enter the edit of magazine copies ");
                l1.setBounds(50, 50, 250, 30);
                f2.add(l1);
                JTextField T1 = new JTextField();
                T1.setBounds(260, 50, 200, 30);
                f2.add(T1);
                JButton b1 = new JButton("Modify");
                b1.setBounds(190, 100, 150, 30);
                f2.add(b1);
                b1.addActionListener(new AbstractAction() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            books.get(i).setNoc(Long.parseLong(T1.getText()));
                            f2.setVisible(false);
                            page2.librarianOperation();
                        } catch (Exception ex) {
                            JLabel b = new JLabel("input is error ");
                            b.setBounds(100, 150, 250, 30);
                            Font f1 = new Font("Arial", Font.BOLD, 15);
                            b.setForeground(Color.red);
                            b.setFont(f1);
                            f2.add(b);
                        }

                    }
                });
            }
        } else {
            JLabel l1 = new JLabel("not found book to modify it");
            l1.setBounds(50, 50, 200, 30);
            f2.add(l1);
            JButton b1 = new JButton("cancel");
            b1.setBounds(190, 100, 150, 30);
            f2.add(b1);
            b1.addActionListener(new AbstractAction() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    f2.setVisible(false);
                    page2.librarianOperation();

                }
            });
        }

    }


    public static void ReceiveBook(String bookname, Date reciveDate, String Sname) {
        String Name = bookname.toLowerCase();
        //   for (Borrow b : Payment.borrow) {

        for (int i = 0; i < PaymentOperation.borrow.size(); i++) {

            Borrow b = PaymentOperation.borrow.get(i);

            if (b.getBookBorrowName().equals(Name) && b.getSName().equals(Sname)) {
                for (Booklet S : booklet) {
                    if (S.getName().equals(Name)) {
                        if (getDateDiff(b.getBorrowDate(), reciveDate, TimeUnit.DAYS) < 12) {
                            S.setNoc(S.getNoc() + 1);
                            Payment.borrow.remove(i);
                            break;


                        } else if (getDateDiff(b.getBorrowDate(), reciveDate, TimeUnit.DAYS) > 12) {
                            S.setNoc(S.getNoc() + 1);
                            Payment.OverPeriodBorrow.add(b);
                            Payment.allProfits.add(b);
                            Payment.borrow.remove(i);
                            break;
                        }
                    }
                }
                for (Magazine S : Magazine) {
                    if (S.getName().equals(Name)) {

                        if (getDateDiff(b.getBorrowDate(), reciveDate, TimeUnit.DAYS) < 20) {
                            S.setNoc(S.getNoc() + 1);
                            Payment.borrow.remove(i);
                            break;

                        } else if (getDateDiff(b.getBorrowDate(), reciveDate, TimeUnit.DAYS) > 20) {
                            S.setNoc(S.getNoc() + 1);
                            Payment.OverPeriodBorrow.add(b);
                            Payment.borrow.remove(i);
                            break;
                        }
                    }
                }
            }
        }
    }

    public static long getDateDiff(Date borrowDate, Date receiveDate, TimeUnit timeUnit) {
        long diffInMillies = receiveDate.getTime() - borrowDate.getTime();
        return timeUnit.convert(diffInMillies, TimeUnit.MILLISECONDS);
    }

    public static void DisplayAll() {
        JFrame f2 = new JFrame();
        f2.setSize(500, 400);
        f2.setVisible(true);
        f2.setLayout(null);
        f2.setResizable(false);
        f2.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        int j = 0;
        if (books.isEmpty()) {
            JLabel l1 = new JLabel("not found books to show it");
            l1.setBounds(50, 50, 200, 30);
            f2.add(l1);
        } else {
            Collections.sort(books);
            for (int i = 0; i < books.size(); i++) {
                JLabel l1 = new JLabel(books.get(i).toString());
                l1.setBounds(50, 50 + j, 200, 30);
                f2.add(l1);
                j = j + 50;
            }
        }
        JButton b3 = new JButton(" Cancel ");
        b3.setBounds(100, 100 + j, 300, 30);
        f2.add(b3);
        b3.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                f2.setVisible(false);
            }
        });
    }
    public static void DisplayStudyBook() {
        System.out.println(booklet.toString().replace("[", "").toString().replace("]", "").toString().replace(",", ""));

    }

    public static void DisplayMagazine() {
        System.out.println(Magazine.toString().replace("[", "").toString().replace("]", "").toString().replace(",", ""));


    }
}
