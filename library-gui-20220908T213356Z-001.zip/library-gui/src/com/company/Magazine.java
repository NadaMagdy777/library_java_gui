package com.company;
public class Magazine extends Book {
    String author;
    private long Mid;

    Magazine(String name, double price, long noc ){
        setName(name);
        setPrice(price);
        setNoc(noc);
        Mid=id;
        id++;
    }
    public  String toString() {
        return ( Mid+ "   "+getName()+ "   " + getPrice()+"  "+getNoc()+"  "+"Magazine" +"\r\n");
    }


}

