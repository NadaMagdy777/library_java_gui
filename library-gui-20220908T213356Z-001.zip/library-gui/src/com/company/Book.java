package com.company;

public abstract class Book implements Comparable<Book> {
    private String name;
    protected static int id=1;
    private Double price;
    private long noc = 0;//number of copy

    public static int getId() {
        return id;
    }

    public static void setId(int id) {
        Book.id = id;
    }

    @Override
    public abstract String toString();

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        if (price >= 0)
            this.price = price;
    }
    public long getNoc() {
        return noc;
    }

    public void setNoc(long noc) {
        if (noc >= 1)
            this.noc = noc;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
       this.name=name;
    }

    @Override
    public int compareTo(Book o) {
        int c=name.compareTo(o.name);
        if(c >0){
            return 1;
      }
        else if(c<0){
            return -1;
        }
        else{
            return 0;
        }


    }
}







