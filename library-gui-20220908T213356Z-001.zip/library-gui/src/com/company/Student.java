package com.company;
import java.util.ArrayList;
import java.util.Date;

public class Student {
    public static int id;
    private int ID;
    private String name;
    static BookOperation S;
    Date enterDate = new Date();
    static ArrayList<Student> students = new ArrayList<>();
    Student(String name) {
        ++id;
        ID = id;
        this.name = name;
        this.enterDate = new Date();
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        if (!name.equals(""))
            this.name = name.toLowerCase();
    }
    public static void addStudent(Student s) {
        students.add(s);
    }
    public  String toString(){
        return ID+"    " +name +"    "+enterDate+" ";
    }
}


